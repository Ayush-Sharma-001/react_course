import React from 'react'

function Live() {
  return (
    <h1 className='w-full text-3xl    h-screen flex align-center justify-center'>
        here all the live students will be seen 
    </h1>
  )
}

export default Live 